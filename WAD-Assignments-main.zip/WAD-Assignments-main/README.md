# WAD-Assignments
SPPU TE_IT WADL Assignments
